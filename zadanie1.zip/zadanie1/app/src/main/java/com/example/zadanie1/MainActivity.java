package com.example.zadanie1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void change(View view){
        TextView text = findViewById(R.id.textt);
        EditText name = findViewById(R.id.name);
        EditText name2 = findViewById(R.id.name2);
        EditText ul = findViewById(R.id.name);
        EditText cook = findViewById(R.id.name2);
        String valName = name.getText().toString();
        String valName2 = name2.getText().toString();
        if(valName.isEmpty() != false || valName2.isEmpty() !=  false){
            text.setText("wpisz imie i nazwisko.");
        }
        else{
            text.setText("twoje imie to "+valName +" twoje nazwisko to: "+ valName2);
        }

    }
}